<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 6-3-2019
 * Time: 12:49
 */

echo "</br><a href='Menu.html'>Terug naar het menu</a>";
echo "<br />";
echo "<br />";
$som = 0;
for ($i = 0; $i < 1000; $i++)
{
    if ($i%3==0 or $i%5==0)
    {
        echo "Deelbaar door 3 en/of 5:";
        $som = $som + $i;
    }
    echo $i . "<br />";
}
echo "<br />";
echo "De som is:" . $som;