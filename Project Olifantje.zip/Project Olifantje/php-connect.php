<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 14-3-2019
 * Time: 10:56
 */

$servernaam = "localhost";
$dbname = "olifantje";
$username = "root";
$password = "";

try
{
    $conn = new PDO ("mysql:host=$servernaam;dbname=$dbname;", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Connectie_gelukt";
}

catch (PDOException $e)
{
    echo "Connectie mislukt: " . $e->getMessage();
}