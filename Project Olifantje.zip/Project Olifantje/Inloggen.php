<?php
/**
 * Created by PhpStorm.
 * User: Ludger_Jukema
 * Date: 20-3-2019
 * Time: 12:37
 */
session_start();
require_once "php-connect.php";
$username=$_POST ["username"];
$password=$_POST["password"];
$wwhash= password_hash($password, PASSWORD_DEFAULT);
//var_dump($wwhash);
//var_dump($username);
//var_dump($password);

$users = $conn->prepare("select id, username, password from users");

$users->execute();

if (isset ($_SESSION['ingelogd'])) {
    echo ("Je was al ingelogd");
    require_once "inloggen2.php";
}

echo "<table>";
foreach ($users as $user) {
    echo "<tr>";
    echo "<td>" . $user["id"] . "</td>";
    echo "<td>" . $user["username"] . "</td>";
    echo "<td>" . $user["password"] . "</td>";
    echo "</tr>";

    if ($username == $user["username"])
    {
        echo "De naam klopt";
        //if ($wwhash == $user["password"])
        if ($password == $user["password"])
        {
            echo "Het password klopt ook";
            $_SESSION["ingelogd"]=true;
            //var_dump($_SESSION);
        }
        else
        {
            echo "Het password klopt niet";
            session_destroy();
        }
    }
    else
    {
        echo "De naam klopt niet";
        session_destroy();
    }
}
echo "</table>";