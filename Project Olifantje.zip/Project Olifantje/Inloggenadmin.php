<?php
/**
 * Created by PhpStorm.
 * User: Ludger_Jukema
 * Date: 17-4-2019
 * Time: 13:36
 */

session_start();
require_once "php-connect.php";
$username=$_POST ["username"];
$password=$_POST["password"];
$rol=$_POST["rol"];
$wwhash= password_hash($password, PASSWORD_DEFAULT);
$isadmin = false;
//var_dump($wwhash);
//var_dump($username);
//var_dump($password);

$users = $conn->prepare("select id, username, password , rol from users");

$users->execute();

//echo "<table>";
foreach ($users as $user) {
    //echo "<tr>";
    //echo "<td>" . $user["id"] . "</td>";
    //echo "<td>" . $user["username"] . "</td>";
    //echo "<td>" . $user["password"] . "</td>";
    //echo "<td>" . $user["rol"] . "</td>";
    //echo "</tr>";

    if ($username == $user["username"]) {
        echo "De naam klopt";
        //if ($wwhash == $user["password"])
        if ($password == $user["password"]) {
            echo "Het password klopt ook";
            $_SESSION["ingelogd"] = true;
            //var_dump($_SESSION);
        }
        if ( $user ["rol"] == "admin") {
            echo "De rol klopt ook";
            $_SESSION ["admin klopt"] = true;
            $isadmin = true;
            //var_dump($_SESSION);
        } else {
            echo "De rol klopt niet";
            $_SESSION ["admin klopt"] = false;
        }
    } else {
        echo "De naam klopt niet";
        //session_destroy();
    }
}
var_dump($_SESSION);

$users->execute();

echo "<table>";
if ($isadmin) {
    foreach ($users as $user) {
        echo "<tr>";
        echo "<td>" . $user["id"] . "</td>";
        echo "<td>" . $user["username"] . "</td>";
        echo "<td>" . $user["password"] . "</td>";
        echo "<td>" . $user["rol"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}
