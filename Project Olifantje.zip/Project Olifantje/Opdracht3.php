<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 14-3-2019
 * Time: 10:59
 */

require_once "php-connect.php";

$users = $conn->prepare("select id, username, password from users");

$users ->execute();

echo "<h1>Laat alle users zien</h1>";
echo "<p>Dit zijn alle gegevens uit de tabel users van de database olifantje</p></br>";

echo "<table>";
foreach ($users as $user)
{
    echo "<tr>";
    echo "<td>" .   $user["id"]       .   "</td>";
    echo "<td>" .   $user["username"]     .   "</td>";
    echo "<td>" .   $user["password"]     .   "</td>";
    echo "</tr>";
}
echo "</table>";
echo "</br><a href='Menu.html'>Terug naar het menu</a>";