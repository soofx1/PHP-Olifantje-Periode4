<?php
/**
 * Created by PhpStorm.
 * User: Ludger_Jukema
 * Date: 18-4-2019
 * Time: 9:24
 */

session_start();
session_destroy();
echo "Alle sessies zijn verwijderd";