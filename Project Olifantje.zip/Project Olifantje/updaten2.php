<?php
/**
 * Created by PhpStorm.
 * User: Ludger_Jukema
 * Date: 8-5-2019
 * Time: 13:13
 */
$id = $_POST ["id"];
//$username = $_POST ["username"];
$password2 = $_POST ["passwordvak"];

require_once "php-connect.php";

$sql = $conn->prepare(
    "update users set password = :password where id = :id");

$sql->bindParam(":id", $id);

$sql->bindParam(":password", $password2);

$sql->execute();

echo "De user is geupdate. <br />";
echo "<a href='Menu.html'> Terug naar het menu </a>";
