<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 6-3-2019
 * Time: 13:38
 */
require_once "php-connect.php";

$id = NULL;
$rol = NULL;
$username = $_POST ["username"];
$ww= $_POST ["password"];
$wwhash= password_hash($ww, PASSWORD_DEFAULT);

$existingUsernames = array ("soof , soof1 , soof2 , soof3");

$sql = $conn->prepare("insert into users values (:id, :username, :password, :rol)");

$sql->bindParam(":id", $id);
$sql->bindParam(":username", $username);
$sql->bindParam(":password", $wwhash);
$sql->bindParam(":rol" , $rol);

$sql ->execute();

if (in_array($username, $existingUsernames)){
    echo $username . "Deze gebruikersnaam bestaat al";
}

array_push($existingUsernames, $username);

echo "Account aangemaakt!";

echo "</br><a href='Menu.html'>Terug naar het menu</a>";
