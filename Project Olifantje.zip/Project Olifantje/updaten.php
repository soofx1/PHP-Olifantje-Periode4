<?php
/**
 * Created by PhpStorm.
 * User: Ludger_Jukema
 * Date: 8-5-2019
 * Time: 13:04
 */
$id = $_POST ["id"];

require_once "php-connect.php";

$users = $conn->prepare("select id, username, password from users where id = :id");

$users->execute(["id"=> $id]);
//var_dump($users);
echo "<form action='updaten2.php' method='post'>";
foreach ($users as $user)
{
    //id mag niet gewijzigd worden
    echo "<input type='hidden' name='id' value='".$user["id"]."'> Het ID is " . $user["id"] . " (Uw ID kunt u niet wijzigen) <br />";

    //echo "Vul hier in uw nieuwe username in: <input type='text' name='username'> De oude username was " .$user["username"]."<br />";

    echo "Vul hier in uw nieuwe password in: <input type='text' name = 'passwordvak'> Het oude password was " .$user["password"]."<br />";
}
echo "<input type='submit'>";
