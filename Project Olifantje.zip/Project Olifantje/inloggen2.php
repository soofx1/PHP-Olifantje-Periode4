<?php
/**
 * Created by PhpStorm.
 * User: Ludger_Jukema
 * Date: 17-4-2019
 * Time: 13:32
 */

echo "Je was al ingelogd";